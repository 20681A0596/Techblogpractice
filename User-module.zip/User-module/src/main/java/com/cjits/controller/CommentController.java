package com.cjits.controller;
import com.cjits.entity.Comment;
import com.cjits.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.logging.Logger;
@RestController
@RequestMapping("/restapi/comment")
public class CommentController {
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Autowired
    private CommentService commentService;

    @PostMapping
    public ResponseEntity<Comment> createComment(@RequestBody Comment comment) {
        logger.warning("Creating new comment: " + comment);
        Comment createdComment = commentService.saveComment(comment);
        return new ResponseEntity<>(createdComment, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Comment>> getAllComments() {
        List<Comment> comments = commentService.getAllComments();
        return new ResponseEntity<>(comments, HttpStatus.OK);
    }

    @GetMapping("/{commentId}")
    public ResponseEntity<?> getCommentById(@PathVariable("commentId") long commentId) {
        Comment comment = commentService.findCommentById(commentId);
        if (comment != null) {
            return new ResponseEntity<>(comment, HttpStatus.OK);
        } else {
            String errorMessage = "Comment not found with ID: " + commentId;
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage);
        }
    }

    @PutMapping("/{commentId}")
    public ResponseEntity<Comment> updateComment(@PathVariable("commentId") long commentId, @RequestBody Comment updatedComment) {
        Comment existingComment = commentService.findCommentById(commentId);
        if (existingComment != null) {
            updatedComment.setCommentId(commentId);
            Comment updated = commentService.updateComment(updatedComment);
            return new ResponseEntity<>(updated, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Endpoint to delete a comment by its ID
    @DeleteMapping("/{commentId}")
    public ResponseEntity<String> deleteComment(@PathVariable("commentId") long commentId) {
        Comment existingComment = commentService.findCommentById(commentId);
        if (existingComment != null) {
            commentService.deleteComment(commentId);
            return new ResponseEntity<>("Comment deleted successfully", HttpStatus.OK);
        } else {
        }
        return null;
    }
}

