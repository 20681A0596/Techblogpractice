package com.cjits.controller;
import com.cjits.entity.Post;
import com.cjits.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.logging.Logger;
@RestController//controller return the response directly
@RequestMapping("/restapi/post")// end point
public class PostController {
    Logger logger=Logger.getLogger(this.getClass().getName());
    private PostService postService;

    @Autowired
    public PostController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping
    public List<Post> getAllPosts() {
        return postService.getAllPosts();
    }

    @GetMapping("{id}")
    public ResponseEntity<?> getPostById(@PathVariable long id) {
        Post post = postService.getPostById(id);
        if (post == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Post not found with ID: " + id);
        }
        return ResponseEntity.ok(post);
    }

    @PostMapping
    public ResponseEntity<Post> createPost(@RequestBody Post post) {
        Post createdPost = postService.createPost(post);
        return new ResponseEntity<>(createdPost, HttpStatus.CREATED);
    }

    @PutMapping("{id}")
    public ResponseEntity<Post> updatePost(@RequestBody Post post,@PathVariable("id")long postId) throws RuntimeException {
        return  new ResponseEntity<Post>(postService.updatePost(postId, post),HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deletePost(@PathVariable ("id") long postId) {
        postService.deletePost(postId);
        return  new ResponseEntity<String>("Deleted successfully",HttpStatus.OK);
    }
}