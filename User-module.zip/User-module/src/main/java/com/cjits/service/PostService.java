package com.cjits.service;
import com.cjits.entity.Post;

import java.util.List;

public interface PostService {
    List<Post> getAllPosts();
    Post getPostById(Long id) throws RuntimeException;
    Post createPost(Post post);
    Post updatePost(Long id, Post post) throws RuntimeException;
    void deletePost(Long id);

}


