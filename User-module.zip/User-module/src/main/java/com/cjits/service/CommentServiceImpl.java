package com.cjits.service;

import com.cjits.entity.Comment;
import com.cjits.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Override
    public Comment saveComment(Comment comment) {
        return commentRepository.save(comment);
    }

    @Override
    public List<Comment> getAllComments() {
        return commentRepository.findAll();
    }

    @Override
    public Comment findCommentById(long commentId) throws RuntimeException {
        Optional<Comment> optionalComment = commentRepository.findById(commentId);
        if (optionalComment.isPresent()) {
            return optionalComment.get();
        } else {
            return null;
        }
    }

    @Override
    public Comment updateComment(Comment updatedComment) throws RuntimeException{
        Optional<Comment> optionalComment = commentRepository.findById(updatedComment.getCommentId());
        if (optionalComment.isPresent()) {
            Comment existingComment = optionalComment.get();
            existingComment.setCommentedText(updatedComment.getCommentedText());
            existingComment.setPostId(updatedComment.getPostId());
            existingComment.setUserId(updatedComment.getUserId());
            return commentRepository.save(existingComment);
        } else {

            throw new RuntimeException("Comment with ID " + updatedComment.getCommentId() + " not found");
        }
    }

    @Override
    public void deleteComment(long commentId) {
        commentRepository.deleteById(commentId);
    }
}

