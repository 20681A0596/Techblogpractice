package com.cjits.service;
import com.cjits.entity.Comment;
import java.util.List;
public interface CommentService {
    Comment saveComment(Comment comment);

    List<Comment> getAllComments();

    Comment findCommentById(long commentId) throws RuntimeException;

    Comment updateComment(Comment updatedComment) throws RuntimeException;

    void deleteComment(long commentId);
}
