package com.cjits;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostRestServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(PostRestServiceApplication.class, args);
	}
}
