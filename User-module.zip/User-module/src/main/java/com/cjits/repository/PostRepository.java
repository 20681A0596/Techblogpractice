package com.cjits.repository;
import com.cjits.entity.Post;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
@Transactional
public interface PostRepository extends JpaRepository<Post, Long> {
    List<Post> findAllByTitleContaining(String title);

}





