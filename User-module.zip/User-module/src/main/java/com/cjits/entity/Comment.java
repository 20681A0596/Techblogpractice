package com.cjits.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Entity
@Table(name = "comments")
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long commentId;

    @Column(name = "commented_text")
    private String commentedText;

    @Column(name = "post_id")
    private long postId;

    @Column(name = "user_id")
    private long userId;

    @Column(name = "comment_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date commentDate;

    public long getCommentId() {
        return commentId;
    }

    public void setCommentId(long commentId) {
        this.commentId = commentId;
    }

    public String getCommentedText() {
        return commentedText;
    }

    public void setCommentedText(String commentedText) {
        this.commentedText = commentedText;
    }

    public long getPostId() {
        return postId;
    }

    public void setPostId(long postId) {
        this.postId = postId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Date getCommentDate() {
        return commentDate;
    }

    public void setCommentDate(Date commentDate) {
        this.commentDate = commentDate;
    }

    @PrePersist
    protected void onCreate() {
        LocalDateTime currentUTCDateTime = LocalDateTime.now();

        ZonedDateTime utcDateTime = currentUTCDateTime.atZone(ZoneId.of("UTC"));

        ZoneId istZone = ZoneId.of("Asia/Kolkata");

        ZonedDateTime istDateTime = utcDateTime.withZoneSameInstant(istZone);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss a");
        String formattedISTDateTime = istDateTime.format(formatter);

        System.out.println("Formatted IST DateTime: " + formattedISTDateTime);

        commentDate = Date.from(istDateTime.toInstant());
    }

    public Comment() {
    }

    @Override
    public String toString() {
        return commentId +
                ", " + commentedText +
                ", " + postId +
                ", " + userId +
                ", " + commentDate;
    }
}
